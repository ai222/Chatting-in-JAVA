/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientserverapplication;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class SendSocket {

    private DatagramPacket datagramPacket;
    private DatagramSocket socket;

    public boolean createSocket(int port, InetAddress address) {
        try {

            socket = new DatagramSocket();
            datagramPacket = new DatagramPacket("".getBytes(), 0, address, port);
            return true;
        } catch (SocketException ex) {
            System.err.println(ex.getMessage());
            return false;
        }
    }
    public void closeSocket(){
        socket.close();
    }
        public void send(String message,int port) throws UnknownHostException {
            
        datagramPacket.setData(message.getBytes());
        datagramPacket.setPort(port);
        
        try {
            socket.send(datagramPacket);
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
    }
}
