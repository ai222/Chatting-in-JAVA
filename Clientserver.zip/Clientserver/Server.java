package clientserverapplication;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author IDVCS
 */
public class Server implements SocketListener {

    MessageListener messageListener;
    private ServerSender sender;
    private ServerReciever reciever;
    private String msg;
    private Scanner sc = new Scanner(System.in);
    private boolean portCreated;
    private int senderPort;

    public Server(MessageListener listener) {
        this.messageListener = listener;
        sender = new ServerSender();
        reciever = new ServerReciever(this);
        reciever.createSocket(2020);
        Thread serverSendThread = new Thread(sender);
        serverSendThread.setName(ServerSender.class.getSimpleName());

        Thread serverReceiveThread = new Thread(reciever);
        serverReceiveThread.setName(ServerReciever.class.getSimpleName());

        serverReceiveThread.start();
        serverSendThread.start();
//        try {
//           portCreated= sender.createSocket(2021, InetAddress.getLocalHost());
//        } catch (UnknownHostException ex) {
//            System.out.println(ex.getMessage());
//        }

    }

    public void sendCreateSocketRequest(int port) {
        try {
            portCreated = sender.createSocket(port, InetAddress.getLocalHost());
        } catch (UnknownHostException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void sendCloseSocketRequest() {
        try {
            sender.closeSocket();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void sendMessage(String msg) {
        try {
            int index = msg.indexOf(',');
            if (index > -1) {
                String[] str = msg.trim().split(",");
                msg = str[0];
                //senderPort=2021;
                System.out.println(str[0]);
                System.out.println(str[1]);
                senderPort = Integer.parseInt(str[1]);
                sender.send(msg,senderPort);
            }
        } catch (UnknownHostException ex) {

        }
    }

    @Override
    public void getSocketMessage(String message) {

        String[] str={"",""};
        System.err.println(message);
        int index = message.indexOf(',');
        String room="";
        if (index > -1) {
            str = message.trim().split(",");
            msg = str[0];
            room=str[2];
            //senderPort=2021;
            System.out.println(str[0]);
            System.out.println(str[1]);
            
            senderPort = Integer.parseInt(str[1]);
            if (msg.contains("Request")) {
                sendCreateSocketRequest(senderPort);
            }
            if (msg.equals("Close")) {
                //sendCloseSocketRequest();
            }
            if (msg.equals("RequestUsers")) {
                messageListener.getMessage(msg+":"+room);
            }
            messageListener.getMessage(":"+str[1]+":"+msg);
        } else {
            messageListener.getMessage(":"+str[1]+":"+message.trim());
        }
        message="";

    }

}
