/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientserverapplication;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author IDVCS
 */
public class RecieveSocket {

    private DatagramSocket socket;
    private DatagramPacket datagramPacket;

    private byte[] buffer = new byte[1024];

    public boolean createSocket(int port) {
        try {
            socket = new DatagramSocket(port);
            return true;
        } catch (SocketException ex) {
            System.err.println(ex.getMessage());
            return false;
        }
    }

    public String recieve() {
        datagramPacket = new DatagramPacket(buffer, buffer.length);
        try {
            socket.receive(datagramPacket);
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
        String message = new String(buffer);
        return message;
    }
}
