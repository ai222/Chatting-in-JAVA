package clientserverapplication;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ClientGUI extends JFrame implements ActionListener, MessageListener, ListSelectionListener {

    private JScrollPane scrollPane = null;
    private JScrollPane scrollPane1 = null;
    private JTextField jTextField_Message = new JTextField(20);
    private JButton jButton_SendMessage = new JButton("Send Message");
    private JButton jButton_request = new JButton("Connect");
    private JTextField jTextField_portNumber = new JTextField(4);
    private JTextField jTextField_hostIP = new JTextField(15);
    private JTextField jTextField_username = new JTextField(15);
    private JLabel jLabel_Heading = new JLabel("Client");
    private JLabel jLabel_portNumber = new JLabel("Port Number");
    private JLabel jLabel_hostIP = new JLabel("Host");
    private JLabel jLabel_username = new JLabel("UserName");
    private JLabel jLabel_info = new JLabel("Rooms");
    private JLabel jLabel_MessageHeading = new JLabel("Message");
    private JPanel jPanel_list = new JPanel();
    private JPanel jPanel_InnerList = new JPanel();
    private JPanel jPanel_PortRequest = new JPanel();
    private JPanel jPanel_layout = new JPanel();
    private JPanel jPanel_info = new JPanel();
    private JPanel jPanel_layout1 = new JPanel(new FlowLayout());
    private DefaultListModel model = new DefaultListModel();
    JList jList_MEssages = new JList(model);
    private DefaultListModel listModel = new DefaultListModel();
    JList jList_info = new JList(listModel);

    Client client = null;
    private String userName;
    private String message;
    private String IP;
    private int port;

    public ClientGUI() {
        super("Client");
       // listModel.addElement("1");
        this.setLayout(new BorderLayout());
//        jLabel_Heading.setVerticalAlignment(SwingConstants.CENTER);
//        jLabel_Heading.setHorizontalAlignment(SwingConstants.CENTER);
        Font font = new Font("SansSerif", Font.BOLD, 20);
        jLabel_Heading.setFont(font);
        jPanel_list.setPreferredSize(new Dimension(400, 300));
        // jPanel_list.setSize(400, 200);
        jPanel_PortRequest.setLayout(new FlowLayout());
        jPanel_PortRequest.setPreferredSize(new Dimension(400, 70));
        //jPanel_PortRequest.add(jLabel_Heading);
        // jPanel_PortRequest.add(new JLabel("   "));
        jPanel_PortRequest.add(jLabel_hostIP);
        jPanel_PortRequest.add(jTextField_hostIP);
        //jPanel_PortRequest.add(new JLabel("   "));
        jPanel_PortRequest.add(jLabel_portNumber);
        jPanel_PortRequest.add(jTextField_portNumber);
        jPanel_PortRequest.add(jLabel_username);
        jPanel_PortRequest.add(jTextField_username);

        jPanel_PortRequest.add(jButton_request);

        //this.add(jPanel_PortRequest, BorderLayout.NORTH);
        jPanel_list.add(jLabel_MessageHeading);
        jPanel_list.add(jTextField_Message);
        jPanel_list.add(jButton_SendMessage);
        scrollPane = new JScrollPane(jList_MEssages);
        jList_MEssages.setVisibleRowCount(8);
        jList_MEssages.setSelectionBackground(Color.RED);
        jList_MEssages.setFixedCellWidth(300);
        scrollPane.setViewportView(jList_MEssages);
        jPanel_InnerList.add(scrollPane);
        scrollPane1 = new JScrollPane(jList_info);
        jList_info.setVisibleRowCount(10);
        jList_info.setSelectionBackground(Color.RED);
        jList_info.setFixedCellWidth(80);
        scrollPane1.setViewportView(jList_info);
        jList_info.addListSelectionListener(this);

        jPanel_list.add(jPanel_InnerList);
        jPanel_info.setPreferredSize(new Dimension(100, 300));
        jPanel_info.add(jLabel_info);
        jPanel_info.add(scrollPane1);

        jPanel_layout1.add(jPanel_info);
        jPanel_layout1.add(jPanel_list);

        jPanel_layout.setLayout(new FlowLayout());
        jPanel_layout.add(jPanel_PortRequest);
        jPanel_layout.add(jPanel_layout1);
        //this.add(jPanel_list, BorderLayout.CENTER);
        this.add(jPanel_layout, BorderLayout.CENTER);
        jButton_SendMessage.addActionListener(this);
        jButton_request.addActionListener(this);
        jButton_SendMessage.setEnabled(false);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500, 400);

    }

    public static void main(String[] args) {
        ClientGUI client = new ClientGUI();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton o = (JButton) e.getSource();
        String name = o.getText();

        switch (name) {
            case "Send Message": {
                client.sendMessage(jTextField_Message.getText());
                break;
            }
            case "Connect": {
                try {

                    //JOptionPane.showMessageDialog(this, "Please Reenter Port Number !!");
                    client = new Client(Integer.parseInt(jTextField_portNumber.getText()), this);
                    if (client.getPortStatus()) {
                        jButton_SendMessage.setEnabled(true);
                        jButton_request.setEnabled(false);
                        JOptionPane.showMessageDialog(this, "Connected !!");
                        client.sendMessage("RequestRooms,5000,0");
                    } else {
                        JOptionPane.showMessageDialog(this, "HostIP or Port number is Incorrect or Already in USe  !!");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Please ReEnter HostIP and Port Number Again!!");
                }
            }

        }
    }

    @Override
    public void getMessage(String message) {
        String[] ss;
        if (!message.equals("")) {
            int index = message.indexOf(":");
            if (index > -1) {

                ss = message.split(":");
                if (ss[0].trim().equals("Rooms")) {
                    for (int i = 1; i < ss.length; i++) {
                        listModel.addElement(ss[i]);
                    }
                }
                 if (ss[0].trim().equals("Users")) {
                     listModel.clear();
                    for (int i = 1; i < ss.length; i++) {
                        listModel.addElement(ss[i]);
                    }
                }
                //msg = ss[0].trim();
            }
        }
        model.addElement(message);
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        System.err.println(((JList)e.getSource()).getSelectedValue());
        String room=((JList)e.getSource()).getSelectedValue().toString();
        client.sendMessage("RequestUsers,5000,"+room);
        
        
    }

}
