/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientserverapplication;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client implements SocketListener {

    private MessageListener msgListener;
    private ClientSender sender;
    private ClientReciever reciever;
    private String msg;
    private Scanner sc = new Scanner(System.in);
    private boolean portCreated;
    private int server_Port = 2020;
    Thread clientReceiveThread = null;

    public Client(int port, MessageListener msgListener) {
        this.msgListener = msgListener;
        sender = new ClientSender();
        reciever = new ClientReciever(this);
        portCreated = reciever.createSocket(port);
        if (portCreated) {
            Thread clientSendThread = new Thread(sender);
            clientSendThread.setName(ClientSender.class.getSimpleName());

            clientReceiveThread = new Thread(reciever);
            clientReceiveThread.setName(ClientReciever.class.getSimpleName());

            clientReceiveThread.start();
            clientSendThread.start();
            try {
                sender.createSocket(2020, InetAddress.getLocalHost());
//            while(true){
//                sendMessage(sc.nextLine());
//            }
            } catch (UnknownHostException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public void sendMessage(String message) {
        String[] str = {"", "", "", ""};
        msg = "";
        try {
            sender.send(message, server_Port);
            if (!message.equals("")) {
                int index = message.indexOf(",");
                if (index > -1) {
                    str = message.split(",");
                    msg = str[0].trim();
                }
            }
            if (msg.equals("Close")) {
                clientReceiveThread.stop();
            }

        } catch (UnknownHostException ex) {

        }
    }

    public boolean getPortStatus() {
        return portCreated;
    }

    @Override
    public void getSocketMessage(String message) {
        msgListener.getMessage(message);

        System.err.println(message);

        //ClientGUI.model.addElement(message);
    }

}
