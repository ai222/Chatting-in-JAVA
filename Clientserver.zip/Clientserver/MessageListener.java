
package clientserverapplication;


interface MessageListener {
    public void getMessage(String message);
}
