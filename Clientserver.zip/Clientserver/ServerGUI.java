package clientserverapplication;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ServerGUI extends JFrame implements ActionListener, MessageListener,ListSelectionListener {

    private JScrollPane scrollPane = null;
    private JTextField jTextField_Message = new JTextField(20);
    private JButton jButton_SendMessage = new JButton("Send Message");
    private JLabel jLabel_Heading = new JLabel("Server");
    private JLabel jLabel_MessageHeading = new JLabel("Message");
    private JPanel jPanel_list = new JPanel();
    private JPanel jPanel_InnerList = new JPanel();
    private DefaultListModel model = new DefaultListModel();
    private JList jList_MEssages = new JList(model);
    

    private Server server = new Server(this);
    private ArrayList rooms= new ArrayList();
    private HashMap usersMap= new HashMap<String,ArrayList>();
    

    public ServerGUI() {
        ArrayList ar=new ArrayList<String>();
        ar.add("User1");
        usersMap.put("Default",ar);
        this.setLayout(new BorderLayout());
        jLabel_Heading.setVerticalAlignment(SwingConstants.CENTER);
        jLabel_Heading.setHorizontalAlignment(SwingConstants.CENTER);
        Font font = new Font("SansSerif", Font.BOLD, 30);
        jLabel_Heading.setFont(font);
        jPanel_list.setSize(400, 50);
        jPanel_list.setSize(400, 200);
        this.add(jLabel_Heading, BorderLayout.NORTH);
        jPanel_list.add(jLabel_MessageHeading);
        jPanel_list.add(jTextField_Message);
        jPanel_list.add(jButton_SendMessage);
        scrollPane = new JScrollPane(jList_MEssages);
        jList_MEssages.setVisibleRowCount(5);
        jList_MEssages.setSelectionBackground(Color.RED);
        jList_MEssages.setFixedCellWidth(300);
        scrollPane.setViewportView(jList_MEssages);
        jPanel_InnerList.add(scrollPane);
        // jPanel_InnerList.add(new JLabel("                                                                      "));
        //jPanel_InnerList.add(jList_MEssages);
        jPanel_list.add(jPanel_InnerList);
        this.add(jPanel_list, BorderLayout.CENTER);
        jList_MEssages.addListSelectionListener(this);
        jButton_SendMessage.addActionListener(this);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500, 400);

    }

    public static void main(String[] args) {
        ServerGUI server = new ServerGUI();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        JButton o = (JButton) e.getSource();
        String name = o.getText();

        switch (name) {
            case "Send Message": {
                int index = jTextField_Message.getText().indexOf(',');
                if (index > -1) {
                    server.sendMessage(jTextField_Message.getText());
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Message or port");
                }
            }
        }
    }

    @Override
    public void getMessage(String message) {
        model.addElement("Client: " + message);
        if(message.contains("RequestRooms")){
            server.sendMessage(processRooms()+",5000");
        }
        if(message.contains("RequestUsers")){
            String[] s=message.split(":");
            server.sendMessage(processUsers(s[1])+",5000");
        }
        message="";
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        String s=jList_MEssages.getSelectedValue().toString();
        String[] str={"",""};
        str=s.trim().split(":");
        jTextField_Message.setText(","+str[2]);
    }
    
    public void addRoom(String room){
        rooms.add(room);
    }
    
    public void removeRoom(String room){
        rooms.remove(room);
    }
    
    public void addUser(String user,String room){
        ((ArrayList)usersMap.get(room)).add(user);
    }
    public void removeUser(String user,String room){
        ((ArrayList)usersMap.get(room)).remove(user);
    }
    public String processRooms(){
        this.rooms.add("Default");
        String rooms="Rooms";
        for(int i=0;i<this.rooms.size();i++){
            rooms=rooms+":" + this.rooms.get(i).toString();
        }
        return rooms;
    }
    
    public String processUsers(String room){
        String users="Users";
        ArrayList s=(ArrayList) usersMap.get(room);
         for(int i=0;i<this.rooms.size();i++){
            users=users+":" + s.get(i).toString();
        }
        return users;
    }
}
